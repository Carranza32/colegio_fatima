<li class="nav-item dropdown">
    <a <?php echo e($attributes->merge([
                                'class' => 'nav-link dropdown-toggle',
                                'href' => $link ?? '#',
                                'data-bs-toggle'=> 'dropdown',
                                'role' => 'button',
                                'aria-expanded' => 'true'
                            ])); ?>>
        <?php if($icon): ?><i class="nav-icon <?php echo e($icon); ?> d-block d-lg-none d-xl-block"></i><?php endif; ?>
        <?php if($title): ?> <span><?php echo e($title); ?></span><?php endif; ?>
    </a>
    <div class="dropdown-menu <?php echo e($open ? 'show' : ''); ?>" data-bs-popper="static">
    <?php echo $slot; ?>

    </div>
</li>
<?php /**PATH /Users/equipo/Herd/colegio_fatima/vendor/backpack/theme-tabler/resources/views/components/menu-dropdown.blade.php ENDPATH**/ ?>