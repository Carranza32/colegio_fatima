<?php $__env->startSection('content'); ?>
    <div class="page page-center">
        <div class="container container-normal py-4">
            <div class="row align-items-center g-4">
                <div class="col-lg">
                    <div class="container-tight">
                        <div class="text-center mb-4 display-6 auth-logo-container">
                            <?php echo backpack_theme_config('project_logo'); ?>

                        </div>
                        <div class="card card-md">
                            <div class="card-body pt-0">
                                <?php echo $__env->make(backpack_view('auth.login.inc.form'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <?php if(config('backpack.base.registration_open')): ?>
                            <div class="text-center text-muted mt-4">
                                <a tabindex="6" href="<?php echo e(route('backpack.auth.register')); ?>"><?php echo e(trans('backpack::base.register')); ?></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg d-none d-lg-block">
                    <img src="https://preview.tabler.io/static/illustrations/undraw_secure_login_pdn4.svg" height="300" class="d-block mx-auto" alt="">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(backpack_view('layouts.auth'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/equipo/Herd/colegio_fatima/vendor/backpack/theme-tabler/resources/views/auth/login/illustration.blade.php ENDPATH**/ ?>