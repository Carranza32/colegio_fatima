<h6 <?php echo e($attributes->merge(['class' => 'dropdown-header'])); ?>>
    <?php if($icon != null): ?><i class="nav-icon <?php echo e($icon); ?>"></i><?php endif; ?>
    <?php if($title!=null): ?> <span><?php echo e($title); ?></span><?php endif; ?>
</h6>
<?php /**PATH /Users/equipo/Herd/colegio_fatima/vendor/backpack/theme-tabler/resources/views/components/menu-dropdown-header.blade.php ENDPATH**/ ?>