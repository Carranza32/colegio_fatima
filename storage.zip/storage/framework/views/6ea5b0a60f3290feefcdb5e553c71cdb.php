<?php
  // Set the page title
  $title = 'Error '.$error_number;
?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12 text-center">
      <div class="card pb-4">
          <div class="error_number">
              <small>ERROR</small><br>
              <?php echo e($error_number); ?>

              <hr>
          </div>
          <div class="error_title text-muted">
              <?php echo $__env->yieldContent('title'); ?>
          </div>
          <?php if(backpack_user()): ?>
              <div class="error_description text-muted">
                <small>
                  <?php echo $__env->yieldContent('description'); ?>
                </small>
              </div>
          <?php endif; ?>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(backpack_user() ? (backpack_theme_config('layout') ? backpack_view('layouts.'.backpack_theme_config('layout')) : backpack_view('errors.blank')) : backpack_view('errors.blank'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/equipo/Herd/colegio_fatima/vendor/backpack/crud/src/resources/views/ui/errors/layout.blade.php ENDPATH**/ ?>