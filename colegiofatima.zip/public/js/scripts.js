$(document).ready(function() {
    // $('.select2').select2();
});
