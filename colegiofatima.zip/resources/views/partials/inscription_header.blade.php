<div>
    <div class="d-flex justify-content-between">
        <div>
            <h1 class="text-center">COLEGIO "PEDRO GEOFFROY RIVAS"</h1>
            <h5>EL TREBOL, SANTA ANA</h5>
        </div>
        <img src="{{ asset('Logo Colegio Pedro Geoffroy Rivas.jpeg') }}" class="responsive-img" height="100" alt="">
    </div>
</div>
